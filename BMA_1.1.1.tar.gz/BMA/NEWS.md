# BMA 1.1-1 (2025-10-01)

- first version released on GitHub
