mle <- function (y, V, mu, t2) 
{
    t5 <- t2 + 0.01
    par0 <- c(mu, t5)
    for (h in 1:2000) {
        a1 <- ((y - mu) * (y - mu) - V)/((V + t5) * (V + t5))
        a2 <- 1/((V + t5) * (V + t5))
        b1 <- y/(V + t5)
        b2 <- 1/(V + t5)
        mu <- sum(b1)/sum(b2)
        t5 <- sum(a1)/sum(a2)
        t5 <- max(0, t5)
        par1 <- c(mu, t5)
        dif1 <- max(abs(par1 - par0))
        if (dif1 < 10^-12) 
            break
        par0 <- par1
    }
    t5 <- max(0, t5)
    return(c(mu, t5))
}

rmle <- function (y, V, mu, t2) 
{
    t5 <- t2 + 0.01
    for (h in 1:2000) {
        a1 <- ((y - mu) * (y - mu) - V)/((V + t5) * (V + t5))
        a2 <- 1/((V + t5) * (V + t5))
        t6 <- sum(a1)/sum(a2)
        dif1 <- abs(t6 - t5)/abs(t6)
        if (dif1 < 10^-12) 
            break
        t5 <- t6
    }
    t5 <- max(0, t5)
    return(t5)
}

BMA <- function (y, V, data=NULL, alpha = 0.95, eform = FALSE) 
{

	data <- data.frame(data)
	y <- data[, deparse(substitute(y))]
	V <- data[, deparse(substitute(V))]
  
    a <- 1 - (1 - alpha)/2
    k <- length(y)
    R <- qchisq(alpha, df = 1)
    w <- 1/V
    mu1 <- sum(w * y)/sum(w)
    var1 <- 1/sum(w)
    ci1 <- mu1 + qnorm(a) * c(-1, 1) * sqrt(var1)
    Q <- sum(w * (y - mu1)^2)
    t2 <- (Q - (k - 1))/(sum(w) - sum(w * w)/sum(w))
    if (t2 <= 0) {
        mu2 <- mu1
        t2 <- 0
        ci2 <- mu1 + qnorm(a) * c(-1, 1) * sqrt(var1)
    }
    if (t2 > 0) {
        w2 <- 1/(V + t2)
        mu2 <- sum(w2 * y)/sum(w2)
        var2 <- 1/sum(w2)
        ci2 <- mu2 + qnorm(a) * c(-1, 1) * sqrt(var2)
    }
    ml <- mle(y, V, mu2, t2)
    mlike0 <- sum(log(dnorm(y, mean = ml[1], sd = sqrt(V + ml[2]))))
    mu3 <- ml[1]
    t3 <- ml[2]
    ci3 <- numeric(2)
    c0 <- ci2[1] - 5
    c1 <- mu3
    for (g in 1:400) {
        c2 <- (c0 + c1)/2
        t4 <- rmle(y, V, c2, t3)
        mlike1 <- sum(log(dnorm(y, mean = c2, sd = sqrt(V + t4))))
        LR1 <- -2 * (mlike1 - mlike0)
        if (LR1 >= R) 
            c0 <- c2
        if (LR1 < R) 
            c1 <- c2
        if (abs(LR1 - R) < 10^-12) 
            break
        if (g == 400) 
            c2 <- NaN
    }
    ci3[1] <- c2
    c0 <- mu3
    c1 <- ci2[2] + 5
    for (g in 1:400) {
        c2 <- (c0 + c1)/2
        t4 <- rmle(y, V, c2, t3)
        mlike1 <- sum(log(dnorm(y, mean = c2, sd = sqrt(V + t4))))
        LR2 <- -2 * (mlike1 - mlike0)
        if (LR2 >= R) 
            c1 <- c2
        if (LR2 < R) 
            c0 <- c2
        if (abs(LR2 - R) < 10^-8) 
            break
        if (g == 400) 
            c2 <- NaN
    }
    ci3[2] <- c2
    ci4 <- numeric(2)
    c0 <- ci2[1] - 5
    c1 <- mu3
    for (g in 1:400) {
        c2 <- (c0 + c1)/2
        t4 <- rmle(y, V, c2, t3)
        SC1 <- sum((y - c2)/(V + t4))^2/sum(1/(V + t4))
        if (SC1 >= R) 
            c0 <- c2
        if (SC1 < R) 
            c1 <- c2
        if (abs(SC1 - R) < 10^-8) 
            break
        if (g == 400) 
            c2 <- NaN
    }
    ci4[1] <- c2
    c0 <- mu3
    c1 <- ci2[2] + 5
    for (g in 1:400) {
        c2 <- (c0 + c1)/2
        t4 <- rmle(y, V, c2, t3)
        SC2 <- sum((y - c2)/(V + t4))^2/sum(1/(V + t4))
        if (SC2 >= R) 
            c1 <- c2
        if (SC2 < R) 
            c0 <- c2
        if (abs(SC2 - R) < 10^-8) 
            break
        if (g == 400) 
            c2 <- NaN
    }
    ci4[2] <- c2
    ci5 <- numeric(2)
    c0 <- ci3[1] - 5
    c1 <- mu3
    for (g in 1:400) {
        c2 <- (c0 + c1)/2
        t4 <- rmle(y, V, c2, t3)
        mlike1 <- sum(log(dnorm(y, mean = c2, sd = sqrt(V + t4))))
        LR0 <- -2 * (mlike1 - mlike0)
        u1 <- (V + t4)^-1
        u2 <- (V + t4)^-2
        u3 <- (V + t4)^-3
        U <- 1 + 2 * sum(u3)/(sum(u1) * sum(u2))
        LR1 <- LR0/U
        if (LR1 >= R) 
            c0 <- c2
        if (LR1 < R) 
            c1 <- c2
        if (abs(LR1 - R) < 10^-12) 
            break
        if (g == 400) 
            c2 <- NaN
    }
    ci5[1] <- c2
    c0 <- mu3
    c1 <- ci3[2] + 5
    for (g in 1:400) {
        c2 <- (c0 + c1)/2
        t4 <- rmle(y, V, c2, t3)
        mlike1 <- sum(log(dnorm(y, mean = c2, sd = sqrt(V + t4))))
        LR0 <- -2 * (mlike1 - mlike0)
        u1 <- (V + t4)^-1
        u2 <- (V + t4)^-2
        u3 <- (V + t4)^-3
        U <- 1 + 2 * sum(u3)/(sum(u1) * sum(u2))
        LR2 <- LR0/U
        if (LR2 >= R) 
            c1 <- c2
        if (LR2 < R) 
            c0 <- c2
        if (abs(LR2 - R) < 10^-8) 
            break
        if (g == 400) 
            c2 <- NaN
    }
    ci5[2] <- c2
    ci6 <- numeric(2)
    c0 <- ci4[1] - 5
    c1 <- mu3
    for (g in 1:400) {
        c2 <- (c0 + c1)/2
        t4 <- rmle(y, V, c2, t3)
        C1 <- sum((V + t4)^-2)/(sum((V + t4)^-1))^2
        S1 <- sum((y - c2)/(V + t4))^2/sum(1/(V + t4))
        SC1 <- S1 * (1 - 0.5 * C1 * (3 - S1))
        if (SC1 >= R) 
            c0 <- c2
        if (SC1 < R) 
            c1 <- c2
        if (abs(SC1 - R) < 10^-8) 
            break
        if (g == 400) 
            c2 <- NaN
    }
    ci6[1] <- c2
    c0 <- mu3
    c1 <- ci4[2] + 5
    for (g in 1:400) {
        c2 <- (c0 + c1)/2
        t4 <- rmle(y, V, c2, t3)
        C2 <- sum((V + t4)^-2)/(sum((V + t4)^-1))^2
        S2 <- sum((y - c2)/(V + t4))^2/sum(1/(V + t4))
        SC2 <- S2 * (1 - 0.5 * C2 * (3 - S2))
        if (SC2 >= R) 
            c1 <- c2
        if (SC2 < R) 
            c0 <- c2
        if (abs(SC2 - R) < 10^-8) 
            break
        if (g == 400) 
            c2 <- NaN
    }
    ci6[2] <- c2
    if (eform == FALSE) {
        A <- list(WLSE = mu1, DL = c(mu2, t2), MLE = c(mu3, t3), 
            WLSE.CI = ci1, DL.CI = ci2, LR.CI = ci3, Bartlett.LR = ci5, 
            Score.CI = ci4, Bartlett.Score = ci6)
        out1(A, alpha)
    }
    if (eform == TRUE) {
        A <- list(WLSE = exp(mu1), DL = c(exp(mu2), t2), MLE = c(exp(mu3), 
            t3), WLSE.CI = exp(ci1), DL.CI = exp(ci2), LR.CI = exp(ci3), 
            Bartlett.LR = exp(ci5), Score.CI = exp(ci4), Bartlett.Score = exp(ci6))
        out1(A, alpha)
    }
}

out1 <- function (A, alpha) 
{
    T <- "Fixed-effects & random-effects meta-analysis"
    t1 <- "Point estimates:"
    t2 <- " Fixed-effects model:"
    t3 <- " DerSimonian-Laird (method-of-moment):"
    t4 <- " Maximum likelihood:"
    t5 <- "Confidence intervals:"
    t6 <- "Confidence level: "
    a1 <- " Fixed-effects model:"
    a2 <- " DerSimonian-Laird (method-of-moment):"
    a3 <- " Likelihood ratio (LR):"
    a4 <- " Bartlett corrected LR:"
    a5 <- " Efficient score:"
    a6 <- " Bartlett-type adjusted score:"
    t7 <- "Variance component estimates:"
    b1 <- round(A[[1]], 3)
    b2 <- round(A[[2]], 3)
    b3 <- round(A[[3]], 3)
    b4 <- round(A[[4]], 3)
    b5 <- round(A[[5]], 3)
    b6 <- round(A[[6]], 3)
    b7 <- round(A[[7]], 3)
    b8 <- round(A[[8]], 3)
    b9 <- round(A[[9]], 3)
    cat("\n", T, "\n", "\n", t1, "\n", t2, b1, "\n", t3, b2[1], 
        "\n", t4, b3[1], "\n", "\n", t7, "\n", t3, b2[2], "\n", 
        t4, b3[2], "\n", "\n", t5, "\n", a1, b4, "\n", a2, b5, 
        "\n", a3, b6, "\n", a4, b7, "\n", a5, b8, "\n", a6, b9, 
        "\n", "\n", t6, alpha, "\n", "\n")
}
